import { NavLink, useNavigate } from "react-router-dom";
import { useAuth } from "../../context/AuthContext";

export default function NavBar() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  async function handleLogout() { await logout(); navigate("/login"); }
  return (
    <nav className="navbar">
      <NavLink to="/" className="navbar-brand">Stock<span>Flow</span></NavLink>
      {user && <div className="navbar-links">
        <NavLink to="/" end className={({isActive}) => isActive ? "active" : ""}>Inventory</NavLink>
        <NavLink to="/add" className={({isActive}) => isActive ? "active" : ""}>Add Product</NavLink>
        <span className="welcome">Welcome, {user.fullName}</span>
        <button onClick={handleLogout} className="logout">Log Out</button>
      </div>}
    </nav>
  );
}
