import { useState } from "react";
import { useNavigate } from "react-router-dom";
import toast from "react-hot-toast";
import { useAuth } from "../../context/AuthContext";
import { createProduct } from "../../services/productService";

const initial = { name:"", sku:"", category:"", quantity:"0", reorderLevel:"5", unitPrice:"0", supplier:"" };

export default function ProductForm() {
  const { token } = useAuth();
  const navigate = useNavigate();
  const [form, setForm] = useState(initial);
  const [submitting, setSubmitting] = useState(false);
  function change(e) { setForm({ ...form, [e.target.name]: e.target.value }); }
  async function submit(e) {
    e.preventDefault(); setSubmitting(true);
    try {
      await createProduct({ ...form, quantity:Number(form.quantity), reorderLevel:Number(form.reorderLevel), unitPrice:Number(form.unitPrice) }, token);
      toast.success("Product added to inventory"); navigate("/");
    } catch (err) { toast.error(err.message || "Could not add product"); }
    finally { setSubmitting(false); }
  }
  return (
    <div className="page">
      <div className="page-header"><div><h1>Add Product</h1><p className="muted">Create a new item in your inventory.</p></div></div>
      <div className="form-card wide">
        <form onSubmit={submit} className="form-grid">
          <label>Product Name<input name="name" value={form.name} onChange={change} required placeholder="e.g. Wireless Keyboard" /></label>
          <label>SKU<input name="sku" value={form.sku} onChange={change} required placeholder="e.g. KB-1001" /></label>
          <label>Category<input name="category" value={form.category} onChange={change} required placeholder="e.g. Electronics" /></label>
          <label>Quantity<input name="quantity" type="number" min="0" value={form.quantity} onChange={change} required /></label>
          <label>Reorder Level<input name="reorderLevel" type="number" min="0" value={form.reorderLevel} onChange={change} required /></label>
          <label>Unit Price<input name="unitPrice" type="number" min="0" step="0.01" value={form.unitPrice} onChange={change} required /></label>
          <label>Supplier<input name="supplier" value={form.supplier} onChange={change} placeholder="Optional" /></label>
          <div className="form-actions full"><button className="btn btn-primary" disabled={submitting}>{submitting ? "Adding..." : "Add Product"}</button><button className="btn btn-secondary" type="button" onClick={() => navigate("/")}>Cancel</button></div>
        </form>
      </div>
    </div>
  );
}
