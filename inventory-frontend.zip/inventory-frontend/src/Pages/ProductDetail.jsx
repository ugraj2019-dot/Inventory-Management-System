import { useEffect, useState } from "react";
import { useNavigate, useParams, Link } from "react-router-dom";
import toast from "react-hot-toast";
import { useAuth } from "../context/AuthContext";
import { getProductById, updateProduct } from "../services/productService";

export default function ProductDetail() {
  const { id } = useParams();
  const { token } = useAuth();
  const navigate = useNavigate();
  const [product, setProduct] = useState(null);
  const [form, setForm] = useState(null);

  useEffect(() => {
    getProductById(id, token).then((data) => { setProduct(data); setForm(data); })
      .catch((err) => toast.error(err.message || "Could not load product"));
  }, [id, token]);

  if (!form) return <p className="status-text">Loading product...</p>;

  function change(e) { setForm({ ...form, [e.target.name]: e.target.value }); }

  async function save(e) {
    e.preventDefault();
    try {
      const data = await updateProduct(id, {
        name: form.name, sku: form.sku, category: form.category,
        quantity: Number(form.quantity), reorderLevel: Number(form.reorderLevel),
        unitPrice: Number(form.unitPrice), supplier: form.supplier,
      }, token);
      setProduct(data); setForm(data);
      toast.success("Inventory updated");
    } catch (err) { toast.error(err.message || "Could not update product"); }
  }

  return (
    <div className="page">
      <div className="page-header"><div><h1>Edit Product</h1><p className="muted">Update stock and product information.</p></div><Link className="btn btn-secondary" to="/">Back to Inventory</Link></div>
      <div className="form-card wide">
        <form onSubmit={save} className="form-grid">
          {[
            ["name","Product Name","text"],["sku","SKU","text"],["category","Category","text"],
            ["quantity","Quantity","number"],["reorderLevel","Reorder Level","number"],["unitPrice","Unit Price","number"],["supplier","Supplier","text"]
          ].map(([name,label,type]) => (
            <label key={name}>{label}<input name={name} type={type} min={type==="number" ? "0" : undefined} step={name==="unitPrice" ? "0.01" : undefined} value={form[name] ?? ""} onChange={change} required={name!=="supplier"} /></label>
          ))}
          <div className="form-actions full"><button className="btn btn-primary" type="submit">Save Changes</button><button className="btn btn-secondary" type="button" onClick={() => navigate("/")}>Cancel</button></div>
        </form>
      </div>
    </div>
  );
}
