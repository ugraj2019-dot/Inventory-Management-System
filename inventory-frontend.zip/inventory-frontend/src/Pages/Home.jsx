import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import toast from "react-hot-toast";
import { useAuth } from "../context/AuthContext";
import { getInventorySummary, getProducts, deleteProduct } from "../services/productService";

export default function Home() {
  const { token } = useAuth();
  const [products, setProducts] = useState([]);
  const [summary, setSummary] = useState(null);
  const [search, setSearch] = useState("");
  const [loading, setLoading] = useState(true);

  async function load() {
    setLoading(true);
    try {
      const [items, stats] = await Promise.all([getProducts(token, search), getInventorySummary(token)]);
      setProducts(items);
      setSummary(stats);
    } catch (err) {
      toast.error(err.message || "Could not load inventory");
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => { load(); }, [token, search]);

  async function handleDelete(id) {
    if (!window.confirm("Delete this product from inventory?")) return;
    try {
      await deleteProduct(id, token);
      toast.success("Product deleted");
      load();
    } catch (err) {
      toast.error(err.message || "Could not delete product");
    }
  }

  return (
    <div className="page">
      <div className="page-header">
        <div>
          <h1>Inventory Dashboard</h1>
          <p className="muted">Track products, stock levels, suppliers, and inventory value.</p>
        </div>
        <Link className="btn btn-primary" to="/add">+ Add Product</Link>
      </div>

      <div className="stats-grid">
        <div className="stat-card"><span>Total Products</span><strong>{summary?.totalProducts ?? "—"}</strong></div>
        <div className="stat-card"><span>Total Units</span><strong>{summary?.totalUnits ?? "—"}</strong></div>
        <div className="stat-card"><span>Inventory Value</span><strong>${Number(summary?.inventoryValue ?? 0).toFixed(2)}</strong></div>
        <div className="stat-card warning"><span>Low Stock</span><strong>{summary?.lowStock ?? "—"}</strong></div>
      </div>

      <div className="toolbar">
        <input className="search" value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Search by product, SKU, or category..." />
      </div>

      {loading ? <p className="status-text">Loading inventory...</p> : products.length === 0 ? (
        <div className="empty-state"><h3>No products found</h3><p>Add your first inventory item to get started.</p><Link className="btn btn-primary" to="/add">Add Product</Link></div>
      ) : (
        <div className="product-grid">
          {products.map((product) => {
            const low = Number(product.quantity) <= Number(product.reorderLevel);
            return (
              <article className="product-card" key={product.id}>
                <div className="product-top">
                  <div>
                    <span className="category-badge">{product.category}</span>
                    <h3>{product.name}</h3>
                    <p className="sku">SKU: {product.sku}</p>
                  </div>
                  <span className={low ? "stock-badge low" : "stock-badge"}>{low ? "Low stock" : "In stock"}</span>
                </div>
                <div className="product-details">
                  <div><span>Quantity</span><strong>{product.quantity}</strong></div>
                  <div><span>Reorder at</span><strong>{product.reorderLevel}</strong></div>
                  <div><span>Unit price</span><strong>${Number(product.unitPrice).toFixed(2)}</strong></div>
                  <div><span>Supplier</span><strong>{product.supplier || "—"}</strong></div>
                </div>
                <div className="card-actions">
                  <Link className="btn btn-secondary" to={`/product/${product.id}`}>View / Edit</Link>
                  <button className="btn btn-danger" onClick={() => handleDelete(product.id)}>Delete</button>
                </div>
              </article>
            );
          })}
        </div>
      )}
    </div>
  );
}
